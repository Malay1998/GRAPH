import matplotlib.pyplot as plt
x = [7, 8, 9]
y = [8, 5, 4]
plt.plot(x, y)
plt.xlabel('x - axis')
plt.ylabel('y - axis')
plt.title('Line Draw')
plt.show()