from matplotlib import pyplot as plt
x = [7, 5, 8, 1, 7]
y = [5, 6, 8, 9, 2]
plt.scatter(x, y)
plt.show()