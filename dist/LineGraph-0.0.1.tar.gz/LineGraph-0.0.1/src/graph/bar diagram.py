from matplotlib import pyplot as plt
y = [6, 3, 1, 7, 2]
plt.hist(y)
plt.show()