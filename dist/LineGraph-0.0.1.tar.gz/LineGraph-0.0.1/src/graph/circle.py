import turtle
t= turtle.Turtle ()
r=50
t.circle(r)